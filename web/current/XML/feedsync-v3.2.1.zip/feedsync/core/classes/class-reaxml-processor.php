<?php
include('class-processor.php');
class REAXML_PROCESSOR extends FEEDSYNC_PROCESSOR {

}

